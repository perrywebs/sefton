

<?php $__env->startSection('title', 'Pin Verification'); ?>
<?php $__env->startSection('content'); ?>
<div class="d-flex flex-column flex-root">
    <!--begin::Authentication - Sign-in -->
    
      <div class="d-flex flex-column flex-lg-row-fluid py-10 mt-19">
        
    <div class="d-flex flex-center flex-column flex-column-fluid">
      
        <div class="w-lg-500px w-100 p-10 p-lg-15 mx-auto ">
          <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.danger-alert','data' => []]); ?>
<?php $component->withName('danger-alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
          <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.success-alert','data' => []]); ?>
<?php $component->withName('success-alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
          
           <?php if(Auth::user()->status !='blocked'): ?>
                 
             
            <form class="form w-100" action="<?php echo e(route('pinstatus')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="text-center mb-10">
                   
                    <div class="text-center mb-10">
                        <div class="logged-user-i">
                            <div class="avatar-w">
                              <img alt="" src="<?php echo e($settings->site_address); ?>/storage/app/public/photos/<?php echo e(Auth::user()->profile_photo_path); ?>" width="100" height="100" style='border-radius: 50%;'>
                            </div>
                            <h1> <?php echo e(Auth::user()->name); ?> <?php echo e(Auth::user()->middlename); ?> <?php echo e(Auth::user()->lastname); ?></h1>
                          </div>
                        
                    </div>
                
                </div>
                <div class="fv-row mb-10">
                    <label class="form-label fs-6 fw-bolder text-dark">Enter your 4 digit verification pin</label>
                    <input class="form-control form-control-lg form-control-solid" name="pin"  maxlength='5' minlength = "4" type="text" placeholder="Enter your 4 digit verification pin" >
                                    </div>
                                <div class="text-center">
                    <button type="submit" class="btn btn-lg btn-primary btn-block fw-bolder me-3 my-2">
                        <span class="indicator-label"> Verify</span>
                   
                </button>
                
                </div>
            </form>
            
            
             <?php else: ?>
             
             
             <div class="alert alert-danger" role="alert">
                <div class='text-center mb-5'>
                     <i class="fal fa-info-circle  fa-3x"></i>
                </div>
  <h4 class="alert-heading text-center">Account Blocked</h4>
  <p>We have blocked your <?php echo e($settings->site_name); ?>  account as a security protection.</p>
  <hr>
  <p class="mb-0">To unblock, contact support on <?php echo e($settings->contact_email); ?> or our livechat</p>
</div>
             
           
             
             <?php endif; ?>
        </div>
    </div>
    <div class="d-flex flex-center flex-wrap fs-6 p-5 pb-0">
    
  </div></div>
    </div>
    
      
     
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\remedybank\resources\views/user/pin.blade.php ENDPATH**/ ?>