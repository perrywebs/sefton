<?php
if (Auth('admin')->User()->dashboard_style == 'light') {
    $text = 'dark';
} else {
    $text = 'light';
}
?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('admin.topmenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="main-panel">
        <div class="content ">
            <div class="page-inner">
                <div class="mt-2 mb-4">
                    <h1 class="title1 ">Manage clients withdrawals</h1>
                </div>
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.danger-alert','data' => []]); ?>
<?php $component->withName('danger-alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.success-alert','data' => []]); ?>
<?php $component->withName('success-alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                <div class="mb-5 row">
                    <div class="col card p-3 shadow ">
                        <div class="bs-example widget-shadow table-responsive" data-example-id="hoverable-table">
                            <span style="margin:3px;">
                                <table id="ShipTable" class="table table-hover ">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Account Holder</th>
                                            <th>Amount </th>
                                            <th>Description</th>
                                            <th>Type</th>
                                            <th>Beneficiary</th>
                                            <th>Status</th>
                                            <th>Date created</th>
                                            <th>Option</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $withdrawals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deposit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <th scope="row"><?php echo e($deposit->id); ?></th>
                                                <td><?php echo e($deposit->duser->name); ?></td>
                                                <td><?php echo e($settings->currency); ?><?php echo e(number_format($deposit->amount)); ?></td>
                                                <td><?php echo e($deposit->Description); ?></td>
                                                <td><?php echo e($deposit->payment_mode); ?></td>
                                                <td>
                                                    <?php if($deposit->payment_mode == 'International Wire Transfer'): ?>
                                                        <?php echo e($deposit->accountname ?? 'N/A'); ?>

                                                    <?php elseif($deposit->payment_mode == 'Cryptocurrency'): ?>
                                                        <?php echo e($deposit->crypto_currency ?? 'N/A'); ?> Wallet
                                                    <?php elseif($deposit->payment_mode == 'PayPal'): ?>
                                                        <?php echo e($deposit->paypal_email ?? 'N/A'); ?>

                                                    <?php elseif($deposit->payment_mode == 'Wise Transfer'): ?>
                                                        <?php echo e($deposit->wise_fullname ?? 'N/A'); ?>

                                                    <?php elseif($deposit->payment_mode == 'Skrill'): ?>
                                                        <?php echo e($deposit->skrill_fullname ?? 'N/A'); ?>

                                                    <?php elseif($deposit->payment_mode == 'Venmo'): ?>
                                                        <?php echo e($deposit->venmo_username ?? 'N/A'); ?>

                                                    <?php elseif($deposit->payment_mode == 'Zelle'): ?>
                                                        <?php echo e($deposit->zelle_name ?? 'N/A'); ?>

                                                    <?php elseif($deposit->payment_mode == 'Cash App'): ?>
                                                        <?php echo e($deposit->cash_app_tag ?? 'N/A'); ?>

                                                    <?php elseif($deposit->payment_mode == 'Revolut'): ?>
                                                        <?php echo e($deposit->revolut_fullname ?? 'N/A'); ?>

                                                    <?php elseif($deposit->payment_mode == 'Alipay'): ?>
                                                        <?php echo e($deposit->alipay_fullname ?? 'N/A'); ?>

                                                    <?php elseif($deposit->payment_mode == 'WeChat Pay'): ?>
                                                        <?php echo e($deposit->wechat_name ?? 'N/A'); ?>

                                                    <?php else: ?>
                                                        <?php echo e($deposit->accountname ?? 'N/A'); ?>

                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <?php if($deposit->status == 'Processed'): ?>
                                                        <span class="badge badge-success"><?php echo e($deposit->status); ?></span>
                                                    <?php elseif($deposit->status == 'On-hold'): ?>
                                                        <span class="badge badge-warning"><?php echo e($deposit->status); ?></span>
                                                    <?php else: ?>
                                                    <span class="badge badge-danger"><?php echo e($deposit->status); ?></span>
                                                    <?php endif; ?>
                                                </td>
                                                <td><?php echo e(\Carbon\Carbon::parse($deposit->created_at)->toDayDateTimeString()); ?>

                                                </td>
                                                <td>
                                                    <a href="<?php echo e(route('processwithdraw', $deposit->id)); ?>"
                                                        class="m-1 btn btn-info btn-sm"><i class="fa fa-eye"></i> View</a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/globalch/public_html/resources/views/admin/Withdrawals/mwithdrawals.blade.php ENDPATH**/ ?>